/* disk.h
 * Christopher Brant
 * cbrant
 * ECE 2230 Sec 001
 * Professor Walt Ligon
 * Due 3/1/17 at 11:59 PM
 */

double seek_time(int current_track, int new_track);

int request_track();

