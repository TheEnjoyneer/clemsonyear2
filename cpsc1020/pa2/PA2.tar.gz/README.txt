/* README.txt
 * Christopher Brant
 * cbrant
 * CPSC 1020 Sec 002 Sp17
 * Yvon Feaster
 * Programming Assignment #2
 * Due 3/19/17 at 11:59 PM
 */

 // Description of problems encountered
 The only problems specifically encountered were the hiccups
 associated with the understanding of the instructions,
 as there are many class public functions that go entirely unused
 throughout the program.

 // Solving the encountered problems
 The encountered problems were solved by intuitively working my
 way through the program and testing code that worked, while still
 not violating any of the direct instructions that were written 
 in the assignment prompt file.

 // My thoughts on the assignment
 Overall, the assignment was fine. I can't complain too much
 about it, as I completed it in under 4 hours total, even though
 that time was stretched out over a couple days.  I think it could
 have been made clearer that not all of the class functions would be
 used, as I originally was of the belief that they all had to be used.
 Otherwise, it was fine and a good practice for classes in C++.