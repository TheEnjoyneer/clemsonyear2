/* README.txt
 * Christopher Brant
 * cbrant
 * CPSC 1020 Sec 002 Sp17
 * Yvon Feaster
 * Programming Assignment #3
 * Due 4/14/17 at 11:59 PM
 */

// Encountered Problems
/* The problems encountered were few and far between,
   to be brutally honest, but probably the most prevalent
   problem encountered was the makefile creation
*/

// Solving Encountered Problems
/* This was a relatively easy fix, as I just had to google how
   to create a makefile and then edit it to fit my needs.
*/

// Thoughts On The Assignment
/* To be brutally honest I am getting sick of the ppm image problems,
   as its just repetitive, although they are relatively easy so I should not
   complain too much.  I would also like to say that we need to set our
   phasers to fun. That is all.
*/

// To Be Noted
/* I turned this in as an EC attempt, yet the prompt isn't entirely thorough
   about the instructions for the extra credit having to do with the 3
   circles.  I did it as the input has to input the circles in the order 
   in which they want to be printed, regardless of the size of the circle.
   Hopefully that is sufficient. If not, oh well. I'm not too terribly worried
   about it.  #Anorak'sAlmanac

   As well as this, my makefile will run for you if you use an input file 
   named input.txt and will print to testoutput.ppm
*/